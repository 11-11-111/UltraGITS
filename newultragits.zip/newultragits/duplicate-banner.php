<!-- Start Banner Area ============================================= -->
<div class="banner-style-one-area overflow-hidden text-light" style="position: relative; overflow: hidden; width: 100%; height: 100vh;">

    <!-- Background Video -->
    <video autoplay muted loop playsinline class="background-video">
        <source src="assets/img/22544-328624736_small.mp4" type="video/mp4">
        Your browser does not support HTML5 video.
    </video>

    <!-- Overlay Content -->
    <div class="banner-style-one" style="position: relative; z-index: 2;">
        <div class="container">
            <div class="content">
                <div class="row align-center">
                    <div class="col-xl-6 col-lg-6">
                        <div class="info pr-35 pr-xs-0 pr-md-0">
                            <h4>Grow your business with us</h4>
                            <h2>Top Digital Marketing Company In Chennai</h2>
                            <p >
                                We are a team of seasoned experts with over 20 years of experience in the <b>digital marketing in Chennai</b>. We specialize in delivering top-quality IT software and hardware solutions, covering everything from core design to comprehensive online marketing strategies.
                            </p>
                            <div class="button">
                                <a class="btn btn-md btn-theme animation" style="background-color:#20377B;" href="contact-us.php">Get A Proposal</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-6 col-lg-6">
                        <div class="thumb">

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- <div class="shape-bottom-center" style="background-image: url('assets/img/shape/5.png');"></div> -->
        <div class="shape-top-right" style="background-image: url('assets/img/shape/6.png');"></div>
    </div>
</div>
<!-- End Banner -->

<!-- Add this CSS in your stylesheet or <style> block -->
<style>
.background-video {
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width:100%;

    object-fit: cover;
    z-index: 1;
}
.banner-style-one-area {
    position: relative;
    width: 100%;
    height: 100vh;
    overflow: hidden;
}
.banner-style-one .content {
    position: relative;
    z-index: 2;
}
</style>
