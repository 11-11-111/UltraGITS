<!DOCTYPE html>
<html lang="en">

<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Digalu - Digital Marketing Agency Template">

    <!-- ========== Page Title ========== -->
    <title>Teams  | UltraGITS</title>

    <!-- ========== Favicon Icon ========== -->
    <link rel="shortcut icon" href="https://www.ultragits.com/assets/img/favicon.png" type="image/x-icon">

    <!-- ========== Start Stylesheet ========== -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <link href="assets/css/elegant-icons.css" rel="stylesheet">
    <link href="assets/css/flaticon-set.css" rel="stylesheet">
    <link href="assets/css/magnific-popup.css" rel="stylesheet">
    <link href="assets/css/swiper-bundle.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/validnavs.css" rel="stylesheet">
    <link href="assets/css/helper.css" rel="stylesheet">
    <link href="assets/css/unit-test.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <!-- ========== End Stylesheet ========== -->


</head>

<body>

    <!--[if lte IE 9]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
    <![endif]-->

    <!-- Start Preloader
    ============================================= -->



    <!-- Header
    ============================================= -->
    <header>
<?php include 'header.php' ?>


    </header>


    <div class="breadcrumb-area text-center" style=" background-image: url(assets/img/shape/breadcrumb.png);">

<div class="container">
    <div class="row">
        <div class="col-lg-8 offset-lg-2">
            <h1>Our Team</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
                    <li class="active">Team</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
</div>

<div class="team-style-one-area text-center default-padding bottom-less">
        <div class="container">
            <div class="row align-center">

                <div class="col-lg-12">
                    <div class="row">
                        <!-- Single Item -->
                        <div class="team-style-one col-xl-3 col-md-6">
                            <div class="team-style-one-item">
                                <div class="thumb">
                                    <img src="assets/img/team-1.webp" alt="Image not found">
                                    <ul class="social">

                                        <li class="twitter">
                                            <a href="#">
                                                <i class="fab fa-linkedin"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="info">
                                    <h4><a href="team-details.html">MOHIDEEEN</a></h4>
                                    <span>CEO & Founder</span>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Item -->

                        <!-- Single Item -->
                        <div class="team-style-one col-xl-3 col-md-6">
                            <div class="team-style-one-item">
                                <div class="thumb">
                                    <img src="assets/img/team-2.webp" alt="Image not found">
                                    <ul class="social">

                                        <li class="twitter">
                                            <a href="#">
                                                <i class="fab fa-linkedin"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="info">
                                    <h4><a href="team-details.html">YUSUF</a></h4>
                                    <span>Co-Founder
</span>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Item -->

                        <!-- Single Item -->
                        <div class="team-style-one col-xl-3 col-md-6">
                            <div class="team-style-one-item">
                                <div class="thumb">
                                    <img src="assets/img/ravi.webp" alt="Image not found">
                                    <ul class="social">

                                        <li class="twitter">
                                            <a href="#">
                                                <i class="fab fa-linkedin"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="info">
                                    <h4><a href="team-details.html">Ravi Kumar</a></h4>
                                    <span>CTO</span>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Item -->

                        <!-- Single Item -->
                        <div class="team-style-one col-xl-3 col-md-6">
                            <div class="team-style-one-item">
                                <div class="thumb">
                                    <img src="assets/img/sufiyan.webp" alt="Image not found">
                                    <ul class="social">

                                        <li class="twitter">
                                            <a href="#">
                                                <i class="fab fa-linkedin"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="info">
                                    <h4><a href="team-details.html">Mr Sufiyan</a></h4>
                                    <span>BDM</span>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Item -->
                    </div>
                </div>
            </div></div></div>


<?php include 'footer.php' ?>
    <!-- jQuery Frameworks
    ============================================= -->
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/jquery.appear.js"></script>
    <script src="assets/js/jquery.easing.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/modernizr.custom.13711.js"></script>
    <script src="assets/js/swiper-bundle.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/progress-bar.min.js"></script>
    <script src="assets/js/circle-progress.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <script src="assets/js/count-to.js"></script>
    <script src="assets/js/jquery.scrolla.min.js"></script>
    <script src="assets/js/YTPlayer.min.js"></script>
    <script src="assets/js/TweenMax.min.js"></script>
    <script src="assets/js/validnavs.js"></script>
    <script src="assets/js/main.js"></script>

</body>

</html>