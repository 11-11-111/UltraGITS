<!DOCTYPE html>
<html lang="en">

<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Digalu - Digital Marketing Agency Template">

    <!-- ========== Page Title ========== -->
    <title>Terms & Conditions | UltraGITS</title>

    <!-- ========== Favicon Icon ========== -->
    <link rel="shortcut icon" href="https://www.ultragits.com/assets/img/favicon.png" type="image/x-icon">

    <!-- ========== Start Stylesheet ========== -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <link href="assets/css/elegant-icons.css" rel="stylesheet">
    <link href="assets/css/flaticon-set.css" rel="stylesheet">
    <link href="assets/css/magnific-popup.css" rel="stylesheet">
    <link href="assets/css/swiper-bundle.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/validnavs.css" rel="stylesheet">
    <link href="assets/css/helper.css" rel="stylesheet">
    <link href="assets/css/unit-test.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <!-- ========== End Stylesheet ========== -->


</head>

<body>

    <!--[if lte IE 9]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
    <![endif]-->


    <!-- Header
    ============================================= -->
    <header>
<?php include 'header.php' ?>


    </header>


    <div class="breadcrumb-area text-center" style=" background-image: url(assets/img/shape/breadcrumb.png);background-color:#e6e6e6;">

<div class="container">
    <div class="row">
        <div class="col-lg-8 offset-lg-2">
            <h1>Terms & Conditions</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
                    <li class="active">Terms & Conditions</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
</div>


<div style="max-width: 90%; margin: 20px auto; padding: 20px; border: 1px solid #ccc; border-radius: 12px; background-color: #fdfdfd;">

    <h4><b>1. Interpretation</b></h4>
    <p>Words with capitalized letters have meanings defined in specific conditions. These definitions apply whether the terms appear in singular or plural form.</p>

    <h4><b>2. Definitions</b></h4>
    <p>For the purpose of these Terms and Conditions:</p>
    <p><b>Affiliate:</b> An entity that controls, is controlled by, or is under common control with a party.</p>
    <p><b>Company:</b> Refers to UltraGITS, located at #43/35, Vedhachalam Street, Arakkonam - 631001.</p>
    <p><b>Service:</b> Refers to the website UltraGITS accessible at https://www.ultragits.com.</p>
    <p><b>You:</b> The individual accessing or using the Service, or the legal entity on behalf of which such individual is accessing the Service.</p>
    <p><b>Device:</b> Any device that can access the Service such as a computer, cellphone, or tablet.</p>
    <p><b>Terms and Conditions:</b> These terms that form the entire agreement between You and the Company regarding the use of the Service.</p>

    <h4><b>3. Acknowledgment</b></h4>
    <p>These Terms and Conditions govern the use of this Service and form an agreement between You and the Company. By accessing or using the Service, You agree to be bound by these Terms. If You disagree, You may not access the Service.</p>

    <h4><b>4. Links to Other Websites</b></h4>
    <p>Our Service may contain links to third-party websites or services not owned or controlled by the Company. We assume no responsibility for the content, privacy policies, or practices of any third-party sites.</p>

    <h4><b>5. Termination</b></h4>
    <p>We may terminate or suspend Your access immediately, without prior notice or liability, for any reason including a breach of these Terms. Upon termination, Your right to use the Service ceases immediately.</p>

    <h4><b>6. Limitation of Liability</b></h4>
    <p>The Company and its suppliers will not be liable for any damages, including but not limited to loss of profits, data, or goodwill, arising from your use or inability to use the Service.</p>

    <h4><b>7. Disclaimer</b></h4>
    <p>The Service is provided "AS IS" and "AS AVAILABLE" with all faults and without warranties of any kind. We do not guarantee the service will be uninterrupted or error-free.</p>

    <h4><b>8. Governing Law</b></h4>
    <p>These Terms shall be governed by the laws of Tamil Nadu, India, without regard to its conflict of law principles.</p>

    <h4><b>9. Disputes Resolution</b></h4>
    <p>If You have any concerns or disputes about the Service, You agree to first try to resolve the issue informally by contacting the Company.</p>

    <h4><b>10. Severability and Waiver</b></h4>
    <p>If any provision of these Terms is held to be unenforceable, the remaining provisions will remain in effect. The failure to enforce any right or provision under these Terms does not waive that right.</p>

    <h4><b>11. Changes to These Terms</b></h4>
    <p>We may update these Terms and Conditions from time to time. We will notify You of any changes by posting the new Terms on this page. Continued use of the Service after the changes means You accept the new Terms.</p>

    <h4><b>12. Contact Us</b></h4>
    <p>If you have any questions about these Terms and Conditions, please contact us:</p>
    <p><b>Email:</b> mail@ultragits.com</p>
    <p><b>Website Contact:</b> <a href="https://www.ultragits.com/contact.php" target="_blank">Click Here</a></p>
    <p><b>Phone:</b> +91 8610213611</p>
    <p><b>Address:</b> #43/35, 2nd Floor, Vedhachalam Street, Arakkonam - 631001</p>

</div>



<?php include 'footer.php' ?>
    <!-- jQuery Frameworks
    ============================================= -->
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/jquery.appear.js"></script>
    <script src="assets/js/jquery.easing.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/modernizr.custom.13711.js"></script>
    <script src="assets/js/swiper-bundle.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/progress-bar.min.js"></script>
    <script src="assets/js/circle-progress.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <script src="assets/js/count-to.js"></script>
    <script src="assets/js/jquery.scrolla.min.js"></script>
    <script src="assets/js/YTPlayer.min.js"></script>
    <script src="assets/js/TweenMax.min.js"></script>
    <script src="assets/js/validnavs.js"></script>
    <script src="assets/js/main.js"></script>

</body>

</html>