 <!-- Start Pricing
    ============================================= -->
    <!--<div class="pricing-area bg-gray default-padding">

        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h4 class="sub-title">Our Packages</h4>
                        <h2 class="title">Select Best Pricing Plans</h2>
                        <div class="devider"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-xl-10 offset-xl-1">
                    <div class="pricing-style-one-box">
                        <div class="row">

                            <div class="col-lg-6 col-md-6 pricing-style-one">
                                <div class="pricing-style-one-item">
                                    <i class="fas fa-rocket"></i>
                                    <div class="pricing-header">
                                        <h4>Basic Plan</h4>
                                        <span>Save 25%</span>
                                    </div>
                                    <div class="price">
                                        <h2><sup>$</sup>25 <sub>/ Monthly</sub></h2>
                                    </div>
                                    <ul>
                                        <li><i class="fas fa-check"></i> Increase traffic 130%</li>
                                        <li><i class="fas fa-check"></i> Backlink analysis</li>
                                        <li><i class="fas fa-check"></i> Organic traffic 215%</li>
                                        <li><i class="fas fa-times"></i> 10 Free Optimization</li>
                                        <li><i class="fas fa-check"></i> Live Support</li>
                                    </ul>
                                    <a class="btn mt-25 circle btn-md btn-theme animation" href="contact-us.html">Purchase Plan</a>
                                </div>
                            </div>



                            <div class="col-lg-6 col-md-6 pricing-style-one active">
                                <div class="pricing-style-one-item">
                                    <div class="span badge">Recommended</div>
                                    <i class="fas fa-gem"></i>
                                    <div class="pricing-header">
                                        <h4>Premium Plan</h4>
                                        <span>Save 35%</span>
                                    </div>
                                    <div class="price">
                                        <h2><sup>$</sup>49 <sub>/ Monthly</sub></h2>
                                    </div>
                                    <ul>
                                        <li><i class="fas fa-check"></i> 25 Analytics Compaign</li>
                                        <li><i class="fas fa-check"></i> 1,300 Keywords</li>
                                        <li><i class="fas fa-times"></i> 25 social media reviews</li>
                                        <li><i class="fas fa-check"></i> SEO Optimized</li>
                                        <li><i class="fas fa-check"></i> Live Support</li>
                                    </ul>
                                    <a class="btn circle mt-25 btn-md btn-theme animation" href="contact-us.html">Purchase Plan</a>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>-->
    <!-- End Pricing -->

    <!-- Start Blog
    ============================================= -->
    <div class="blog-area blog-grid default-padding bottom-less" style="background-image: url(assets/img/shape/28.png);">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h4 class="sub-title">Recent </h4>
                        <h2 class="title">Our Latest Case Studies</h2>
                        <div class="devider"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <!-- Single item -->
                <div class="col-lg-4 col-md-6 single-item">
                    <div class="item">
                        <div class="thumb">
                            <a href="blog-single-with-sidebar.html"><img src="assets/img/blog/1.jpg" alt="Thumb"></a>
                            <div class="tags">
                                <a href="#">App</a>
                            </div>
                        </div>
                        <div class="info">
                            <div class="meta">
                                <ul>
                                    <li>
                                        <a href="#"><i class="far fa-calendar-alt"></i> 12 Auguest, 2024</a>
                                    </li>
                                    <li>
                                        <a href="#"><i class="far fa-user-circle"></i> Admin</a>
                                    </li>
                                </ul>
                            </div>
                            <h4>
                                <a href="blog-single-with-sidebar.html">Discovery earnestly public command mentions the main.</a>
                            </h4>
                            <a href="blog-single-with-sidebar.html" class="button-regular">
                                Continue Reading <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <!-- End Single item -->

                <!-- Single item -->
                <div class="single-item col-lg-4 col-md-6">
                    <div class="item">
                        <div class="thumb">
                            <a href="blog-single-with-sidebar.html"><img src="assets/img/blog/2.jpg" alt="Thumb"></a>
                            <div class="tags">
                                <a href="#">Digital Marketing</a>
                            </div>
                        </div>
                        <div class="info">
                            <div class="meta">
                                <ul>
                                    <li>
                                        <a href="#"><i class="far fa-calendar-alt"></i> 15 November, 2024</a>
                                    </li>
                                    <li>
                                        <a href="#"><i class="far fa-user-circle"></i> Admin</a>
                                    </li>
                                </ul>
                            </div>
                            <h4>
                                <a href="blog-single-with-sidebar.html">Considered imprudence of he friendship boisterous.</a>
                            </h4>
                            <a href="blog-single-with-sidebar.html" class="button-regular">
                                Continue Reading <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <!-- End Single item -->

                <!-- Single item -->
                <div class="single-item col-lg-4 col-md-6">
                    <div class="item">
                        <div class="thumb">
                            <a href="blog-single-with-sidebar.html"><img src="assets/img/blog/3.jpg" alt="Thumb"></a>
                            <div class="tags">
                                <a href="#">Web Application</a>
                            </div>
                        </div>
                        <div class="info">
                            <div class="meta">
                                <ul>
                                    <li>
                                        <a href="#"><i class="far fa-calendar-alt"></i> 26 March, 2024</a>
                                    </li>
                                    <li>
                                        <a href="#"><i class="far fa-user-circle"></i> Admin</a>
                                    </li>
                                </ul>
                            </div>
                            <h4>
                                <a href="blog-single-with-sidebar.html">Providing top quality cleaning and related services charms.</a>
                            </h4>
                            <a href="blog-single-with-sidebar.html" class="button-regular">
                                Continue Reading <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <!-- End Single item -->

            </div>
        </div>
    </div>
    <!-- End Blog -->